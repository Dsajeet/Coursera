INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P100', '1','L100','R100','2013-10-25 8:00','2013-10-25 17:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P100', '2','L101','R101','2013-10-25 12:00','2013-10-25 17:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P100', '3','L102','R102','2013-10-25 7:00','2013-10-25 16:30','1');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P100', '4','L100','R102','2013-10-25 18:00','2013-12-12 22:00','1');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P101', '1','L103','R100','2013-12-03 18:00','2013-12-03 20:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P101', '2','L105','R100','2013-12-03 18:30','2013-12-03 19:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P101', '3','L103','R103','2013-12-03 19:00','2013-12-03 20:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P102', '1','L103','R100','2013-12-05 18:00','2013-12-05 19:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P102', '2','L105','R100','2013-12-05 18:00','2013-12-05 21:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P102', '3','L103','R103','2013-12-05 19:00','2013-12-05 22:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P103', '1','L103','R100','2013-12-12 18:00','2013-12-12 21:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P103', '2','L105','R100','2013-12-12 18:00','2013-12-12 21:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P103', '3','L103','R103','2013-12-12 19:00','2013-12-12 22:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P104', '1','L101','R104','2013-10-26 18:00','2013-10-26 22:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P104', '2','L100','R104','2013-10-26 18:00','2013-10-26 22:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P105', '1','L101','R104','2013-10-25 18:00','2013-10-25 22:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P105', '2','L100','R104','2013-10-25 18:00','2013-10-25 22:00','4');
# #
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P199', '1','L100','R100','2013-12-10 8:00','2013-12-10 12:00','1');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P349', '1','L103','R100','2013-12-12 12:00','2013-12-12 15:30','1');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P85', '1','L100','R100','2013-10-25 9:00','2013-10-25 17:00','5');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P85', '2','L102','R101','2013-10-25 8:00','2013-10-25 17:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P85', '3','L104','R100','2013-10-25 10:00','2013-10-25 17:00','3');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P95', '1','L100','R100','2013-10-26 8:00','2013-10-26 17:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P95', '2','L102','R101','2013-10-26 9:00','2013-10-26 17:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P95', '3','L106','R100','2013-10-26 10:00','2013-10-26 15:00','4');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P95', '4','L100','R103','2013-10-26 13:00','2013-10-26 17:00','2');
#
INSERT INTO EventPlanLine(planNo, lineNo, locNo, resNo, timeStart, timeEnd, numberFLD) VALUES ('P95', '5','L101','R104','2013-10-26 13:00','2013-10-26 17:00','2');
