CREATE TABLE Facility (
  facNo   CHAR(11)    NOT NULL,
  facName VARCHAR(30) NOT NULL,
  CONSTRAINT FacilityPK PRIMARY KEY (facNo)
);