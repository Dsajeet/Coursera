#Insert a new row in the Location table related to the Facility row in modification problem 1.
#The new row should have “Door” for the location name.
INSERT INTO Location (locNo, facNo, locName) VALUES ('L107', 'F104', 'Door');