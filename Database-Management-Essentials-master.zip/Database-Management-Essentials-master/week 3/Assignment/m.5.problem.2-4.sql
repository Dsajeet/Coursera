#Change the location name of “Door” to “Gate” for the row inserted in modification problem 2.
UPDATE Location
SET locName = 'Gate'
WHERE locNo = 'L107';