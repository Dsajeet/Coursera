#Delete the row inserted in modification problem 3.
DELETE FROM Location
WHERE locNo = 'L108';