SELECT DISTINCT
  c.city,
  c.state,
  c.zip
FROM Customer AS c ;