#Insert a new row into the Facility table with facility name “Swimming Pool”.
INSERT INTO Facility (facNo, facName) VALUES ('F104', 'Swimming Pool');