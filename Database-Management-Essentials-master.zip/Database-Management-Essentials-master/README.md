# Database-Management-Essentials

Assignments of Coursera Course "Database Management Essentials".

##### Assignments:

**Week 1**: Introduction to Databases and DBMSs; <em>Nothing to commit</em> 

[**Week 2**](week%202/Assignment): Relational Data Model and the CREATE TABLE Statement;

[**Week 3**](week%203/Assignment): Basic Query Formulation with SQL <em>and</em> Extended Query Formulation with SQL;

[**Week 4**](week%204/Assignment): Notation for Entity Relationship Diagrams <em>and</em> ERD Rules and Problem Solving;

[**Week 5**](week%205/): Developing Business Data Models <em>and</em> Data Modeling Problems and Completion of an ERD;

[**Week 6**](week%206/): Schema Conversion;

[**Week 7**](week%207/): Normalization Concepts and Practice.

---
Good luck.

